<?php $this->load->view('admin/credit_notes/table_html'); ?>
